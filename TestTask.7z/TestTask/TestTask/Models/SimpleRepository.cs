﻿using System;
using System.Collections.Generic;

namespace TestTask.Models
{
    public class SimpleRepository : IRepository
    {
        private static SimpleRepository sharedRepository = new SimpleRepository();
        private List<HelpDeskMessage> helpDeskMessages = new List<HelpDeskMessage>();

        public static SimpleRepository SharedRepository => sharedRepository;
        public SimpleRepository()
        {
            DateTime deadline = new DateTime(2022, 2, 1);
            for (int i = 1; i <= 40; i++)
            {
                var hdm = new HelpDeskMessage { id = i, Message = string.Format("Very bad situation No.{0}! Urgent help needed!", i), Deadline = deadline.AddDays(i - 1), Created = DateTime.Now, Resolved = false};
                AddHelpDeskMessage(hdm);
            }
        }
        public IEnumerable<HelpDeskMessage> HelpDeskMessages => helpDeskMessages;
        public void AddHelpDeskMessage(HelpDeskMessage hdm) => helpDeskMessages.Add(hdm);
        public void DeleteHelpDeskMessage(int id)
        {
            foreach (HelpDeskMessage hdm in helpDeskMessages)
            {
                if (hdm.id == id)
                {
                    helpDeskMessages.Remove(hdm);
                    break;
                }
            }
        }
    }
}

﻿using System.Collections.Generic;

namespace TestTask.Models
{
    public interface IRepository
    {
        IEnumerable<HelpDeskMessage> HelpDeskMessages { get; }
        void AddHelpDeskMessage(HelpDeskMessage hdm);
        void DeleteHelpDeskMessage(int id);
    }
}

﻿using System;

namespace TestTask.Models
{
    public class HelpDeskMessage
    {
        public int id { get; set; }
        public string Message { get; set; }
        public DateTime Created { get; set; }
        public DateTime Deadline { get; set; }
        public bool Resolved { get; set; }
    }
}

﻿using System;
using Microsoft.AspNetCore.Mvc;
using System.Linq;
using TestTask.Models;

namespace TestTask.Controllers
{
    public class HomeController : Controller
    {
        public IRepository Repository = SimpleRepository.SharedRepository;
        public IActionResult Index() => View("Index", Repository.HelpDeskMessages.Where(hdm => !hdm.Resolved).OrderByDescending(hdm => hdm.id));
        [HttpGet]
        public IActionResult AddHelpDeskMessage() => View(new HelpDeskMessage());
        [HttpGet]
        public IActionResult AddNewHelpDeskMessage(string message, string deadline)
        {
            var id = Repository.HelpDeskMessages.Max(hdm => hdm.id) + 1;
            HelpDeskMessage hdm = new HelpDeskMessage
            {
                id = id,
                Message = message,
                Created = DateTime.Now,
                Deadline = Convert.ToDateTime(deadline),
                Resolved = false
            };
            Repository.AddHelpDeskMessage(hdm);

            return Json("Ok");
        }
        [HttpGet]
        public IActionResult EditHelpDeskMessage(int id)
        {
            var hdm = Repository.HelpDeskMessages.Where(hdm => hdm.id == id).FirstOrDefault();

            return View("EditHelpDeskMessage", hdm);
        }
        [HttpGet]
        public IActionResult SaveHelpDeskMessage(int id, string message, string deadline, bool resolved)
        {
            var hdm = Repository.HelpDeskMessages.Where(hdm => hdm.id == id).FirstOrDefault();
            if (hdm != null)
            {
                hdm.Message = message;
                hdm.Deadline = Convert.ToDateTime(deadline);
                hdm.Resolved = resolved;
            };

            return Json("Ok");
        }
        [HttpGet]
        public IActionResult DeleteHelpDeskMessage(int id)
        {
            Repository.DeleteHelpDeskMessage(id);

            return Json("Ok");
        }
    }
}

﻿using TestTask.Models;
using Xunit;

namespace TestTask.Tests
{
    public class HelpDeskMessageTests
    {
        [Fact]
        public void CanChangeMessage()
        {
            // Arrange
            var hdm = new HelpDeskMessage { id = 1, Message = "Very bad situation! Urgent help needed!", Created = System.DateTime.Now, Deadline = System.DateTime.Now.AddDays(3), Resolved = false };

            // Act
            hdm.Message = "Not so urgent problem.";

            // Assert
            Assert.Equal("Not so urgent problem.", hdm.Message);
        }

        [Fact]
        public void CanChangeDeadline()
        {
            // Arrange
            var hdm = new HelpDeskMessage { id = 1, Message = "Very bad situation! Urgent help needed!", Created = System.DateTime.Now, Deadline = System.DateTime.Now.AddDays(3), Resolved = false };

            // Act
            hdm.Deadline = new System.DateTime(2022, 1, 31);

            // Assert
            Assert.Equal(new System.DateTime(2022, 1, 31), hdm.Deadline);
        }

        [Fact]
        public void CanChangeResolved()
        {
            // Arrange
            var hdm = new HelpDeskMessage { id = 1, Message = "Very bad situation! Urgent help needed!", Created = System.DateTime.Now, Deadline = System.DateTime.Now.AddDays(3), Resolved = false };

            // Act
            hdm.Resolved = true;

            // Assert
            Assert.True(hdm.Resolved);
        }
    }
}

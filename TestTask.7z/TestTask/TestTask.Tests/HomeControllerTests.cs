﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using TestTask.Controllers;
using TestTask.Models;
using Xunit;

namespace TestTask.Tests
{
    public class HomeControllerTests
    {
        class ModelCompleteFakeRepository : IRepository
        {
            private List<HelpDeskMessage> helpDeskMessages = new List<HelpDeskMessage>();
            public ModelCompleteFakeRepository()
            {
                getHelpDeskMessages();
            }
            public IEnumerable<HelpDeskMessage> HelpDeskMessages => helpDeskMessages;
            public void AddHelpDeskMessage(HelpDeskMessage hdm)
            {
                // 
            }
            public void DeleteHelpDeskMessage(int id)
            {
                //
            }
            private void getHelpDeskMessages()
            {
                DateTime deadline = new DateTime(2022, 2, 1);
                for (int i = 40; i >= 1; i--)
                {
                    var hdm = new HelpDeskMessage { id = i, Message = string.Format("Very bad situation No.{0}! Urgent help needed!", i), Deadline = deadline.AddDays(i - 1), Created = DateTime.Now, Resolved = false };
                    helpDeskMessages.Add(hdm);
                }
            }
        }
        [Fact]
        public void IndexActionModelIsComplete()
        {
            // Arrange
            var controller = new HomeController();
            controller.Repository = new ModelCompleteFakeRepository();

            // Act
            var model = (controller.Index() as ViewResult)?.ViewData.Model as IEnumerable<HelpDeskMessage>;

            // Assert
            Assert.Equal(controller.Repository.HelpDeskMessages, model,
                Comparer.Get<HelpDeskMessage>((m1, m2) => m1.Message == m2.Message && m1.Deadline == m2.Deadline && m1.Resolved == m2.Resolved));
        }
        class ModelCompleteFakeRepositoryOnlyResolved : IRepository
        {
            private List<HelpDeskMessage> helpDeskMessages = new List<HelpDeskMessage>();
            public ModelCompleteFakeRepositoryOnlyResolved()
            {
                getHelpDeskMessages();
            }
            public IEnumerable<HelpDeskMessage> HelpDeskMessages => helpDeskMessages;
            public void AddHelpDeskMessage(HelpDeskMessage hdm)
            {
                // 
            }
            public void DeleteHelpDeskMessage(int id)
            {
                //
            }
            private void getHelpDeskMessages()
            {
                DateTime deadline = new DateTime(2022, 2, 1);
                for (int i = 40; i >= 1; i--)
                {
                    var hdm = new HelpDeskMessage { id = i, Message = string.Format("Very bad situation No.{0}! Urgent help needed!", i), Deadline = deadline.AddDays(i - 1), Created = DateTime.Now, Resolved = i % 2 == 0 ? false : true };
                    if (hdm.Resolved)
                    {
                        helpDeskMessages.Add(hdm);
                    }
                }
            }
        }
        [Fact]
        public void IndexActionModelIsCompleteOnlyResolved()
        {
            // Arrange
            var controller = new HomeController();
            controller.Repository = new ModelCompleteFakeRepositoryOnlyResolved();

            // Act
            var model = (controller.Index() as ViewResult)?.ViewData.Model
                as IEnumerable<HelpDeskMessage>;

            // Assert
            Assert.Equal(controller.Repository.HelpDeskMessages, model,
                Comparer.Get<HelpDeskMessage>((m1, m2) => m1.Message == m2.Message && m1.Deadline == m2.Deadline && m1.Resolved == m2.Resolved));
        }
    }
}
